/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package starwarsfight;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author aliso
 */
import javax.swing.ImageIcon;

public class Player1 extends Movel {

	private int dx, dy;
        private volatile int jump = 0;

        
        Sprite player = new Sprite(8, 200, 300);
               
        

	public Player1(int x, int y) {
                
               
                //QUI CARREGAMOS AS IMAGENS DE NOSSA SPIRTE!!!!!!!
		//PARA O VETOR DE ImageIcon[] !!!

                player.cenas[0] = new ImageIcon(StarWarsFight.class.getResource("/res/thor_1/0.png"));
                player.cenas[1] = new ImageIcon(StarWarsFight.class.getResource("/res/thor_1/1.png"));
                player.cenas[2] = new ImageIcon(StarWarsFight.class.getResource("/res/thor_1/2.png"));
                player.cenas[3] = new ImageIcon(StarWarsFight.class.getResource("/res/thor_1/3.png"));
                player.cenas[4] = new ImageIcon(StarWarsFight.class.getResource("/res/thor_1/4.png"));
                player.cenas[5] = new ImageIcon(StarWarsFight.class.getResource("/res/thor_1/5.png"));
                
                player.cenas[6] = new ImageIcon(StarWarsFight.class.getResource("/res/thor_1/0_1.png"));
                player.cenas[7] = new ImageIcon(StarWarsFight.class.getResource("/res/thor_1/2_1.png"));
                    
		player.largura = 100;	//LARGURA DO VILÃƒO
		player.altura =  200;	//ALTURA DO VILÃƒO , mas nÃ£o vou usar isso agora..

                imagem = player.cenas[player.cena].getImage();
                //AQUI CHAMEI O MÃ‰TODO ANIMAR
		//imagens[1] = vilao1.cenas[1].getImage();
		//imagens[2] = vilao1.cenas[2].getImage();
                
               
               	altura = imagem.getHeight(null);
		largura = imagem.getHeight(null);

		this.x = x;
		this.y = y;
	}

	public void mexer() {
		x += dx;
		y += dy;

		if (this.x < 1) {
			this.x = 1;
		}
		
		if (this.x > 1000) {
			this.x = 1000;
		}

		if (this.y < 150) {
			this.y = 150;
		}

		if (this.y > 250) {
			this.y = 250;
		}
	}


	public void keyPressed(KeyEvent tecla) {
		int codigo = tecla.getKeyCode();


		if (codigo == KeyEvent.VK_UP) {
                        System.out.println("y"+this.y);
                        dy = -100;
                        imagem = player.cenas[4].getImage();

		}
		
		if (codigo == KeyEvent.VK_DOWN) {
			dy = 1;
		}

		if (codigo == KeyEvent.VK_LEFT) {
			dx = -1;
                        imagem = player.cenas[7].getImage();
		}
		
		if (codigo == KeyEvent.VK_RIGHT) {
			dx = 1;
                        imagem = player.cenas[2].getImage();
		}
                if (codigo == KeyEvent.VK_X) {
                        System.out.println("teste"+player.cena);
                        imagem = player.cenas[5].getImage();
                        
		}
	}

	public void keyReleased(KeyEvent tecla) {
		int codigo = tecla.getKeyCode();

		if (codigo == KeyEvent.VK_UP) {
			dy = 100;
                        imagem = player.cenas[0].getImage();

		}
		
		if (codigo == KeyEvent.VK_DOWN) {
			dy = 0;
                         imagem = player.cenas[0].getImage();

		}
		
		if (codigo == KeyEvent.VK_LEFT) {
			dx = 0;
                         imagem = player.cenas[6].getImage();

		}
		
		if (codigo == KeyEvent.VK_RIGHT) {
			dx = 0;
                        imagem = player.cenas[0].getImage();

		}
                if (codigo == KeyEvent.VK_X) {
                        System.out.println("teste"+player.cena);
                        imagem = player.cenas[0].getImage();
                        
		}
	}

	public Rectangle getBounds() {
		return new Rectangle(x, y, largura, altura);
	}

	public boolean isVisivel() {
		return visible;
	}

	public void setVisivel(boolean visible) {
		this.visible = visible;
	}



	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public Image getImagem() {
		return imagem;
	}
        

	@Override
	public int getAltura() {
		return altura;
	}

	@Override
	public int getLargura() {
		return largura;
	}
        
}
