/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package starwarsfight;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;

import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.LineBorder;
/**
 *
 * @author aliso
 */
public class StarWarsFight  extends JFrame  {

    /**
     * @param args the command line arguments
     */
    
    private static final long serialVersionUID = 1L;
    BufferedImage backBuffer;	
    int FPS = 30;
    int janelaW = 1050;
    int janelaH = 591;
    
    //Sprite vilao1 = new Sprite(3, 200, 300);
    //Sprite vilao2 = new Sprite(3, 100, 200);

    public StarWarsFight() {

    }
        
        
    public static void main(String[] args) {
        // TODO code application logic here
        StarWarsFight game = new StarWarsFight();
	game.run();
    }
    	public void atualizar() {

	}
        
    	private JMenuBar construirMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.WHITE);
		menuBar.setBorder(new LineBorder(Color.red));
		JMenu menu = new JMenu("Opções");
		JMenuItem sobre = new JMenuItem("Sobre");
		sobre.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane
						.showMessageDialog(
								null,
								"Desenvolvido por Fernando Duarte Galloro \ncontato: fernandodrt@live.com \n\nVersão 1.0 - 2012",
								"Informações", JOptionPane.INFORMATION_MESSAGE);
			}
		});

		JMenuItem sair = new JMenuItem("Sair");
		sair.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);

			}
		});

		menu.add(sobre);
		menu.add(new JSeparator());
		menu.add(sair);
		menuBar.add(menu);
		setJMenuBar(menuBar);

		return menuBar;
	}

	private JPanel construirFase() {
		Fase fase = new Fase();
		add(fase);
		return fase;
	}

	private void configurarTela() {
		setSize(janelaW, janelaH);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
		setTitle("Fight");
               
                
	}
        

        public void run() {
		construirMenuBar();
		construirFase();
		configurarTela();
		/*while (true) {
			atualizar();
			desenharGraficos();
				try {
					//Thread.sleep(1000/FPS);
				} catch (Exception e) {
					System.out.println("Thread interrompida!");
				}
		}*/
	}
    
}
