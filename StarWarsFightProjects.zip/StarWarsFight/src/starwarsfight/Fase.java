package starwarsfight;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Fase extends JPanel implements ActionListener {

	/**
	 * Serial gerado automaticamente apenas para efeito de serialização
	 */
	private static final long serialVersionUID = -5079021684583630134L;

	private Image fundo;

        
        private Player1 boneco1;
        private Player2 boneco2;

	private Timer timer;



	private boolean emJogo;

	private int[][] coordenadas = { { 2380, 29 }, { 2600, 59 }, { 1380, 89 },
			{ 780, 109 }, { 580, 139 }, { 880, 239 }, { 790, 259 },
			{ 760, 50 }, { 790, 150 }, { 1980, 209 }, { 560, 45 }, { 510, 70 },
			{ 930, 159 }, { 590, 80 }, { 530, 60 }, { 940, 59 }, { 990, 30 },
			{ 920, 200 }, { 900, 259 }, { 660, 50 } };

	public Fase() {
		setFocusable(true);
		setDoubleBuffered(true);
		addKeyListener(new TecladoAdapter());

		ImageIcon referencia = new ImageIcon(StarWarsFight.class.getResource("/res/Battlefron.jpg"));
		fundo = referencia.getImage();
                
                boneco1 = new Player1(100,250);
                
                boneco2 = new Player2(500,250);

		emJogo = true;



		timer = new Timer(5, this);
		timer.start();
	}



	public void paint(Graphics g) {
		Graphics2D graficos = (Graphics2D) g;
		graficos.drawImage(fundo, 0, 0, null);

		if (emJogo) {
			
                        
                        graficos.drawImage(boneco1.getImagem(), boneco1.getX(), boneco1.getY(), this);
                        
                        graficos.drawImage(boneco2.getImagem(), boneco2.getX(), boneco2.getY(), this);


			graficos.setColor(Color.white);

		} else {
			ImageIcon fimJogo = new ImageIcon(StarWarsFight.class.getResource("/res/game_over.jpg"));

			graficos.drawImage(fimJogo.getImage(), 0, 0, null);
		}
		g.dispose();
	}

	@Override
	public void actionPerformed(ActionEvent e) {

                boneco1.mexer();
                boneco2.mexer();
		checarColisoes();
		repaint();
	}

	public void checarColisoes() {
		Rectangle formaBoneco1 = boneco1.getBounds();
                Rectangle formaBoneco2 = boneco2.getBounds();
               

		if (formaBoneco1.intersects(formaBoneco2)) {
				boneco1.setVisivel(false);
				boneco2.setVisivel(false);
				emJogo = false;
		}
		

	
	}

	private class TecladoAdapter extends KeyAdapter {

		@Override
		public void keyPressed(KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_ENTER) {
				emJogo = true;
                                boneco1 = new Player1(100,250);
                                boneco2 = new Player2(500,250);
	
			}

                        boneco1.keyPressed(e);
                        boneco2.keyPressed(e);
		}

		@Override
		public void keyReleased(KeyEvent e) {
                        boneco1.keyReleased(e);
                        boneco2.keyReleased(e);
		}
	}
}
